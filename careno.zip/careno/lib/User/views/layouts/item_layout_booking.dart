import 'package:flutter/material.dart';

class ItemLayoutBooking extends StatelessWidget {
  const ItemLayoutBooking({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
