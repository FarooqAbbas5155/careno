class farooq{
  String name;
  double lat;
  double lng;

  farooq({
    required this.name,
    required this.lat,
    required this.lng,
  });
}
List<farooq> event = [
  farooq(name: 'Host 1', lat: 30.964755,lng: 70.939934),
  farooq(name: "Host 2", lat: 30.964740, lng: 70.939914),
  farooq(name: "Host 3", lat: 30.964780, lng: 70.939974),
  farooq(name: "Host 4", lat: 30.964710, lng: 70.939904),
  farooq(name: "Host 5", lat: 30.964790, lng: 70.939924),
  farooq(name: "Host 6", lat: 30.964700, lng: 70.939904),
];